package com.example.cd

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomnavigation.BottomNavigationView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MlActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var emptyStateTextView: TextView
    private lateinit var movieAdapter: MlAdapter // Correct adapter for displaying wishlist movies

    private val wishlistMovies = mutableListOf<Movie>() // Wishlist movies data

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.ml_activity)

        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)
        recyclerView = findViewById(R.id.mlview)
        emptyStateTextView = findViewById(R.id.emptyStateTextView)

        recyclerView.layoutManager = LinearLayoutManager(this)
        movieAdapter = MlAdapter(wishlistMovies) // Correctly initialize MlAdapter
        recyclerView.adapter = movieAdapter

        fetchWishlist() // Fetch the wishlist data from API

        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    // Navigate to MainActivity
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
                    startActivity(intent)
                    true
                }
                R.id.recc -> {
                    // Stay in MlActivity
                    true
                }
                else -> false
            }
        }
    }

    private fun fetchWishlist() {
        val sharedPref = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val token = sharedPref.getString("auth_token", null)

        if (token != null) {
            val apiService = RetrofitInstance.api
            apiService.getWishlist("Bearer $token").enqueue(object : Callback<MovieResponseML> {
                override fun onResponse(call: Call<MovieResponseML>, response: Response<MovieResponseML>) {
                    if (response.isSuccessful) {
                        response.body()?.let { movieResponse ->
                            val movies = movieResponse.data // Update based on API response format
                            if (movies.isNotEmpty()) {
                                recyclerView.visibility = View.VISIBLE
                                emptyStateTextView.visibility = View.GONE
                                wishlistMovies.clear()
                                wishlistMovies.addAll(movies)
                                movieAdapter.notifyDataSetChanged()
                            } else {
                                recyclerView.visibility = View.GONE
                                emptyStateTextView.visibility = View.VISIBLE
                            }
                        }
                    } else {
                        Toast.makeText(
                            this@MlActivity,
                            "Failed to fetch wishlist: ${response.message()}",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }

                override fun onFailure(call: Call<MovieResponseML>, t: Throwable) {
                    Toast.makeText(this@MlActivity, "Error: ${t.message}", Toast.LENGTH_SHORT).show()
                }
            })
        } else {
            Toast.makeText(this, "No token found", Toast.LENGTH_SHORT).show()
        }
    }
}
